
/**
 * Write a description of class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.IOException;
public class Main
{
       public static void main(String[] args) throws IOException {
        Controller controller = new Controller();
        controller.showMenu();
    }
}
