
/**
 * Write a description of class Model here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Comparator;
public class Nebulae implements Comparator<Nebulae>
{
    private int Club_ref_number;
    private String name;
    private int catalogue_number;
    private boolean item_observed;
    private String date;

    public Nebulae(){
        this.Club_ref_number = 0;
    }
    public Nebulae(int club_ref_number,String name, int catalogue_number,boolean item_observed, String date) {
        Club_ref_number = club_ref_number;
        this.name = name;
        this.catalogue_number = catalogue_number;
        this.item_observed = item_observed;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getClub_ref_number() {
        return Club_ref_number;
    }

    public void setClub_ref_number(int club_ref_number) {
        club_ref_number = club_ref_number;
    }

    public void setCatalogue_number(int catalogue_number) {
        this.catalogue_number = catalogue_number;
    }

    public int getCatalogue_number() {
        return catalogue_number;
    }


    public boolean isItem_observed() {
        return item_observed;
    }

    public void setItem_observed(boolean item_observed) {
        this.item_observed = item_observed;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        if(isItem_observed()) {
            return "Item-Neb-" + getClub_ref_number() + ","+getName()+"," + getCatalogue_number() + "," +
                    "YES" + "," + getDate()+"\n";
        }
        else {
            return "Item-Neb-" + getClub_ref_number() + ","+getName()+"," + getCatalogue_number() + "," +
                    "NO"+"\n";
        }
    }

    @Override
    public int compare(Nebulae o1, Nebulae o2) {
        return o1.getDate().compareTo(o2.getDate());
    }
    
    
}


