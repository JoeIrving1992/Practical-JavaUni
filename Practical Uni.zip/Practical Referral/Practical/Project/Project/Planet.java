
/**
 * Write a description of class Model here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Comparator;
public class Planet implements Comparator<Planet>
{
    private int Club_ref_number;
    private String name;
    private int brightness;
    private boolean item_observed;
    private String date;

    public Planet(){
        this.Club_ref_number = 0;
    }
    public Planet(int club_ref_number,String name, int brightness,boolean item_observed, String date) {
        Club_ref_number = club_ref_number;
        this.name = name;
        this.brightness = brightness;
        this.item_observed = item_observed;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getClub_ref_number() {
        return Club_ref_number;
    }

    public void setClub_ref_number(int club_ref_number) {
        Club_ref_number = club_ref_number;
    }

    public void setBrightness(int brightness) {
        this.brightness = brightness;
    }

    public int getBrightness() {
        return brightness;
    }


    public boolean isItem_observed() {
        return item_observed;
    }

    public void setItem_observed(boolean item_observed) {
        this.item_observed = item_observed;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        if(isItem_observed()) {
            return "Item-Pla-" + getClub_ref_number() + ","+getName()+"," + getBrightness() + "," +
                    "YES" + "," + getDate()+"\n";
        }
        else {
            return "Item-Pla" + getClub_ref_number() + ","+getName()+"," + getBrightness() + "," +
                    "NO"+"\n";
        }
    }

    @Override
    public int compare(Planet o1, Planet o2) {
        return o1.getDate().compareTo(o2.getDate());
    }
    
    
}


