
/**
 * Write a description of class Controller here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.io.IOException;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

public class Controller
{


   private LinkedList<Asteroid> asteroidList;
   private LinkedList<Planet> planetList;
   private LinkedList<Galaxy> galaxyList;
   private LinkedList<Nebulae> nebulaeList;
  

    public Controller(){
      
        asteroidList = new LinkedList<>();
        planetList = new LinkedList<>();
        galaxyList = new LinkedList<>();
        nebulaeList = new LinkedList<>();
    
        addDataAsteroid_List();
        addDataPlanet_List();
        addDataGalaxy_List();
        addDataNebulae_List();
    }
    
    
    void addDataAsteroid_List(){
        asteroidList.add(new Asteroid(1,"Vesta",8,false,"000000"));
        asteroidList.add(new Asteroid(2,"Pallas",50,true,"201222"));
        asteroidList.add(new Asteroid(3,"Juno",33,false,"000000"));
        asteroidList.add(new Asteroid(4,"Toutatis",22,true,"201222"));
        asteroidList.add(new Asteroid(5,"Eros",9,false,"000000"));

    }
    
    void addDataPlanet_List(){
        planetList.add(new Planet(1,"Earth",8,false,"000000"));
        planetList.add(new Planet(2,"Jupiter",50,true,"201222"));
        planetList.add(new Planet(3,"Neptune",33,false,"000000"));
        planetList.add(new Planet(4,"Mars",22,true,"201222"));
        planetList.add(new Planet(5,"Saturn",9,false,"000000"));

    }
    
     void addDataGalaxy_List(){
        galaxyList.add(new Galaxy(1,"Whirlpool",8,false,"000000"));
        galaxyList.add(new Galaxy(2,"Milky Way",50,true,"201222"));
        galaxyList.add(new Galaxy(3,"Andromeda",33,false,"000000"));
        galaxyList.add(new Galaxy(4,"Messier",22,true,"201222"));
        galaxyList.add(new Galaxy(5,"Sombrero",9,false,"000000"));

    }
    
     void addDataNebulae_List(){
        nebulaeList.add(new Nebulae(1,"Helix",8,false,"000000"));
        nebulaeList.add(new Nebulae(2,"Wolf-Rayet",50,true,"201222"));
        nebulaeList.add(new Nebulae(3,"Ring",33,false,"000000"));
        nebulaeList.add(new Nebulae(4,"Lagoon",22,true,"201222"));
        nebulaeList.add(new Nebulae(5,"Crab",9,false,"000000"));

    }
    
    public void showMenu() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Observed Object System for a local astronomy club");
        char c = 'n';
        while(c!= 113 || c!= 81 ){
            System.out.println("A. Add Object\nB. Delete Object\n" +
                    "C. Update Item\nD. Display Object\nE. Display All Objects\n" +
                    "S. Sort Object (By Date)\nT. Sort Objects (By ID)\nQ. quit");
            c = scanner.next().charAt(0);
            if(c == 'A' || c == 'a'){
                addItemObject();
            }else if(c == 'B' || c == 'b'){
                deleteItem();
            }else if(c == 'C' || c == 'c'){
                updateItem();
            }else if(c == 'D' || c == 'd'){
               displayObject();
            }else if (c == 'E' || c == 'e'){
                displayAll();
            }
            else if(c == 'S' || c == 's') {
                sortData();
                System.out.println("Data Sorted");
                displayAll();
            }
            else if(c == 'T' || c == 't'){
                sortDataByID();
                System.out.println("Data Sorted");
                displayAll();
            }
            else if(c == 'Q' || c == 'q'){
                System.exit(0);
            }

        }
    }
    private void sortData(){
        //Sorts Asteroid list 
        asteroidList.sort(Comparator.comparing(Asteroid::getDate));
        asteroidList.sort((o1,o2)->o2.getDate().compareTo(o1.getDate()));
        
        //sorts Galaxy list 
        galaxyList.sort(Comparator.comparing(Galaxy::getDate));
        galaxyList.sort((o1,o2)->o2.getDate().compareTo(o1.getDate()));
        
        //Sort Nerbulae List 
        nebulaeList.sort(Comparator.comparing(Nebulae::getDate));
        nebulaeList.sort((o1,o2)->o2.getDate().compareTo(o1.getDate()));
        
        //Sorts Planet List 
        planetList.sort(Comparator.comparing(Planet::getDate));
        planetList.sort((o1,o2)->o2.getDate().compareTo(o1.getDate()));
    }
    
    private void sortDataByID(){
        //Sort list by ID 
        asteroidList.sort(Comparator.comparingInt(Asteroid::getClub_ref_number));
        galaxyList.sort(Comparator.comparingInt(Galaxy::getClub_ref_number));
        nebulaeList.sort(Comparator.comparingInt(Nebulae::getClub_ref_number));
        planetList.sort(Comparator.comparingInt(Planet::getClub_ref_number));
    }
    public void displayAll(){
        displayAsteroid();
        displayGalaxy();
        displayPlanet();
        displayNebulae();
    } 
    public void displayAsteroid(){
        System.out.println("-------Asteroids----------");
        for (Asteroid asteroid:
             asteroidList) {
            System.out.println(asteroid.toString());
        }
    }
    
    public void displayGalaxy(){
        System.out.println("-------Galaxies----------");
        for (Galaxy galaxy:
             galaxyList) {
            System.out.println(galaxy.toString());
        }
    }
    
    public void displayPlanet(){
        System.out.println("-------Planets----------");
        for (Planet planet:
             planetList) {
            System.out.println(planet.toString());
        }
    }
    
    public void displayNebulae(){
        System.out.println("-------Planetary Nebulae----------");
        for (Nebulae nebulae:
             nebulaeList) {
            System.out.println(nebulae.toString());
        }
    }
   
    private void updateItem() throws IOException {
        deleteItem();
        addItemObject();
    }
    private void deleteItem() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Item ID:");
        int choice = scanner.nextInt();
        for (Asteroid asteroid:
             asteroidList) {
            if (asteroid.getClub_ref_number() == choice){
                System.out.println(asteroid.toString());
                asteroidList.remove(asteroid);
                break;
            }
        }
    }
    
      private void displayObject() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose Item Type:");
        System.out.println("1. Asteroid 2. Galaxy 3. Nebulae 4. Planet");
    
        int choice = scanner.nextInt();
        if(choice == 1){
            displayAsteroid();
        }else if(choice == 2){
            displayGalaxy();
        }else if(choice == 3){
            displayNebulae();
        }else if(choice == 4){
            displayPlanet();
        }else{
            System.out.println("Invalid Choice!");
        }
    }
    
    private void addItemObject() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose Object Type:");
        System.out.println("1. Asteroid 2. Galaxy 3. Nebula 4. Planet");
        int choice = scanner.nextInt();
        if(choice == 1){
            //Add Asteroid
            System.out.print("Enter Name:");
            String name = scanner.next();
            System.out.print("Enter Brightness:");
            String brightness_scan = scanner.next();
            int brightness = Integer.parseInt(brightness_scan);
            Asteroid id = new Asteroid();
            if(asteroidList.size() >= 1)
                id = asteroidList.get(asteroidList.size()-1);
            asteroidList.add(new Asteroid(id.getClub_ref_number()+1,name, brightness,false,""));
        }else if(choice == 2){
            //Galaxy
             System.out.print("Enter Name:");
            String name = scanner.next();
            System.out.print("Enter Catalogue Number:");
            String catalogue_number_scan = scanner.next();
            int catalogue_number = Integer.parseInt(catalogue_number_scan);
            Galaxy id = new Galaxy();
            if(asteroidList.size() >= 1)
                id = galaxyList.get(galaxyList.size()-1);
            galaxyList.add(new Galaxy(id.getClub_ref_number()+1,name, catalogue_number,false,""));
        }else if(choice == 3){
            //Nebulae
             System.out.print("Enter Name:");
            String name = scanner.next();
            System.out.print("Enter Catalogue Number:");
            String catalogue_number_scan = scanner.next();
            int catalogue_number = Integer.parseInt(catalogue_number_scan);
            Nebulae id = new Nebulae();
            if(asteroidList.size() >= 1)
                id = nebulaeList.get(nebulaeList.size()-1);
            nebulaeList.add(new Nebulae(id.getClub_ref_number()+1,name, catalogue_number,false,""));
        }else if(choice == 4){
            //Add Planet
            System.out.print("Enter Name:");
            String name = scanner.next();
            System.out.print("Enter Brightness:");
            String brightness_scan = scanner.next();
            int brightness = Integer.parseInt(brightness_scan);
            Planet id = new Planet();
            if(asteroidList.size() >= 1)
                id = planetList.get(planetList.size()-1);
            planetList.add(new Planet(id.getClub_ref_number()+1,name, brightness,false,""));
        }else{
            System.out.println("Invalid Choice!");
        }
    }
}